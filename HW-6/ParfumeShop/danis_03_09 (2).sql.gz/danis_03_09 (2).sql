-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1:3306
-- Время создания: Сен 08 2020 г., 15:19
-- Версия сервера: 10.3.22-MariaDB
-- Версия PHP: 7.4.5

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `danis_03.09`
--

-- --------------------------------------------------------

--
-- Структура таблицы `parfumeshop`
--

CREATE TABLE `parfumeshop` (
  `id` int(11) NOT NULL,
  `brand` varchar(20) NOT NULL,
  `price` decimal(10,0) NOT NULL DEFAULT 0,
  `image` text NOT NULL,
  `image_alt` text NOT NULL,
  `description` text NOT NULL,
  `full_descr` text NOT NULL,
  `look` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Дамп данных таблицы `parfumeshop`
--

INSERT INTO `parfumeshop` (`id`, `brand`, `price`, `image`, `image_alt`, `description`, `full_descr`, `look`) VALUES
(1, 'Sauvage', '100', 'images/sauvage.jpg', 'images/sauvage1.jpg', 'Cпрей 100 мл', 'Sauvage - творение, вдохновленное широкими открытыми пространствами. Чистейшее синее небо, простирающееся над скалистыми вершинами гор. Смелая композиция для верного себе мужчины.\r\n\r\n\"В качестве отправной точки при создании Sauvage я использовал мужчину. Яркую и столь очевидную мужественность. Образ мужчины, который выходит за рамки времени и моды\".\r\n\r\nФрансуа Демаши, парфюмер-создатель Dior', 0),
(2, 'Joy', '30', 'images/joy.jpg', 'images/joy1.jpg', 'Cпрей 50 мл', 'Интенсивная парфюмерная вода JOY от Dior - новый аромат со взрывными цветочными нотами и многогранным сияющим парфюмерным шлейфом.\r\nОслепительное сияние сочной ноты Цитруса сливается с ярким блеском Грасской Розы и Жасмина, подчеркнутым мягкими нотами Сандалового Дерева и Ванили.\r\n\r\nЦветочный фейерверк, наполненный радостью.', 0),
(5, 'Spice Blend', '120', 'images/spiceBlend.jpg', 'images/spiceBlend1.jpg', 'Cпрей 125 мл', 'Spice Blend - чувственный аромат с удивительной концентрацией пикантных специй со всего мира и свежим аккордом экстракта Рома. Это путешествие, приправленное специями: жизнерадостная нота пикантного Черного Перца из Мадагаскара сочетается с пронзительно красивой нотой экстракта Имбиря и другими яркими специями, наполняющими аромат древесными оттенками.\r\nХАРАКТЕР\r\nSpice Blend - это аромат с сильным характером, который объединяет самые насыщенные и свежие специи с яркой живой нотой экстракта Рома. Каждая нота играет важную роль в этой глубокой ольфакторной композиции.\r\n\r\nОТЛИЧИТЕЛЬНАЯ ЧЕРТА\r\nАромат мгновенно захватывает, чередуя ощущения свежести и тепла.', 0);

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `parfumeshop`
--
ALTER TABLE `parfumeshop`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `parfumeshop`
--
ALTER TABLE `parfumeshop`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
